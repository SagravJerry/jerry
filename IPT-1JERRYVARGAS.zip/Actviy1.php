
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<title>NightBeach | florida web design</title>
</head>

<body>
<div id="container">
        <div id="header">
            <h1>IPT-1<span class="off">BSIT-2C</span></h1>
            <h2>VARGAS,JERRY M.</h2>
        </div>   
        
        <div id="menu">
            <ul>
                <li class="menuitem"><a href="index.php">Home</a></li>
                <li class="menuitem"><a href="#">About</a></li>
                <li class="menuitem"><a href="Actviy1.php">Chapter 1</a></li>
                <li class="menuitem"><a href="Actviy10.php">Chapter 2</a></li>
                
              <li class="menuitem"><a href="docs.php">Contact</a></li>
            </ul>
     </div>
      
       <div id="leftmenu">

        <div id="leftmenu_top"></div>

                <div id="leftmenu_main">    
                
                <h3>Chapter 1 Topics</h3>
                        
                <ul>
                    <li><a href="Actviy1.php">Activity 1</a></li>
                    <li><a href="Actviy2.php">Activity 2</a></li>
                    <li><a href="Actviy3.php">Activity 3</a></li>
                    <li><a href="Actviy4.php">Activity 4</a></li>
                    <li><a href="Actviy5.php">Activity 5</a></li>
                    <li><a href="Actviy6.php">Activity 6</a></li>
                    <li><a href="Actviy7.php">Activity 7</a></li>
                    <li><a href="Actviy8.php">Activity 8</a></li>
                    <li><a href="Actviy9.php">Activity 9</a></li>
                 
                </ul>
</div>
                
                
              <div id="leftmenu_bottom"></div>
        </div>
        
        
        <div id="content">
        
        
        <div id="content_top"></div>
        <div id="content_main">
            <h1>Activity 1</h1>
            <h2>Designing and Creating my Portflio</p></h2>
               <a href="1stPage.php.php" ><h2>My Potfolio</h2></a>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        <center> <img src="images/portf.png" width ="80%"></center>
          
         
       
            <p>&nbsp;</p>
</div>
        <div id="content_bottom"></div>/
            /
          <div id="footer"><h3><a href="http://www.bryantsmith./om">florida web design</a></h3></div>
      </div>
   </div>
</body>
</html>